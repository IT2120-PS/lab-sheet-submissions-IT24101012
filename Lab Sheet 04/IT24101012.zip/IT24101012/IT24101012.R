#part 01
data <- read.table("Exercise.txt", header = TRUE, sep = "")
fix(data)
names(data) <- c("Team Attendance"," Team Salary","Years")
attach(data)

#part 02 (a)
boxplot(x1, main="Box Plot for Team attendance", outline=TRUE, notch=TRUE, horizontal=TRUE)
boxplot(x2, main="Box Plot for Team Salary", outline=TRUE, notch=TRUE, horizontal=TRUE)
boxplot(x3, main="years", outline=TRUE, notch=TRUE, horizontal=TRUE)

hist(x1, ylab="Frequency", xlab="Team Attendance", main="Histogram for Team Attendance")
hist(x2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(x3, ylab="Frequency", xlab="Years", main="Histogram for Years")

stem(x1)
stem(x2)
stem(x3)

#part 02 (b)
mean(x1)
mean(x2)
mean(x3)

median(x1)
median(x2)
median(x3)

sd(x1)
sd(x2)
sd(x3)

#part 02(c)

summary(x1)
summary(x2)
summary(x3)

quantile(x1)
quantile(x1) [2]
quantile(x1) [4]

#part 2 (d)
IQR(x1)
IQR(x2)
IQR(x3)

#part 3

get.mode<-function(y){
  counts<-table(x3)
  names(counts[counts == max(counts)])
}

get.mode(x3)
table(x3)
max(counts)
counts ==  max(counts)
counts[counts ==  max(counts)]
names(counts[counts ==  max(counts)])

#part 4

get.outliers <- function(z){
  q1 <- quantile(z)[2][2]
  q3 <- quantile(z)[4][4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

get.outliers(x1)
get.outliers(x2)
get.outliers(x3)



  
  
