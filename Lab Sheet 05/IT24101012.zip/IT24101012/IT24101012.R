setwd("C:\\Users\\IT24101012\\Downloads\\IT24101012")
getwd()

data <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")
fix(data)

attach(data)

names(data) <-c("x1")
attach(data)

hist(x1, main="Histogram for number of Delivery_Time_(minutes)")


Histogram <- hist(x1, main="Histogram for number of Delivery_Time_(minutes)", breaks = seq(20,70,length=10),right=FALSE)


#question 03

breaks <- round(Histogram$breaks)
freq <- Histogram$counts
mids <- Histogram$mids

Classes <- c()

for(i in 1:length(breaks)-1){
  Classes[i]<- paste0("[", breaks[i], ",", breaks[i+1],")")
}


#question 04

lines(mids, freq)
plot() <- cumsum(table(cut(x1$Delivery_Time_.minutes., breaks = seq(20,70,by=5), right = TRUE)))
plot(seq(22.5,67.5, by=5),cf, type="0", main = "Cumulative Frequency Polygon", xlab ="Delivery Time", ylab="Frequency",)















